﻿# SILICON — AI Automation Project Suite

> **SILICON** is a modular portfolio of AI-powered automation systems, each designed to solve real-world business and content workflows using Large Language Models, Speech AI, multi-API integrations, and agentic architectures.

---

## Vision

SILICON is built on a single philosophy: **human work that can be described in a sentence should be automated end-to-end.** Every system in this suite eliminates a repetitive manual loop — whether thats chasing client approvals over WhatsApp, or manually compiling YouTube analytics each month — and replaces it with an agentic, always-on pipeline.

---

## Project Modules

### PS-3 · AI-Powered WhatsApp Approval & Lead Assistant System

**The Big Idea:** A content studio uses WhatsApp to get client approvals for video scripts. Traditionally, writers would DM clients, chase replies, manually update spreadsheets, and individually email escalations to their team lead. This system eliminates every single one of those manual steps.

#### How It Works — End to End

```
Writer triggers → Script dispatched via WhatsApp → Client replies "Yes"/"No"
    → Google Sheets auto-updated → Writer emailed automatically
    → If no reply after X hours → Reminder WhatsApp sent to client
    → If still no reply → Escalation auto-emailed to Team Lead
    → Team Lead asks voice query → AI responds with voice note
```

#### Core Capabilities

| Feature | Description |
|---|---|
| **Script Dispatch** | Auto-sends personalized WhatsApp messages with assigned scripts to each client |
| **Approval Sync** | Instantly updates the Google Sheets database on client reply (Yes/No) |
| **Email Notifications** | Fires Gmail notifications to writers on every client decision |
| **Smart Follow-ups** | Cron-scheduler auto-triggers reminder messages for unresponsive clients |
| **Escalation Engine** | Escalates ignored reminders to the Team Lead via email, automatically |
| **Voice Query Assistant** | Team Lead sends a voice note question in Hindi; system responds with a live AI voice note |

#### Technology Stack

- **Runtime:** Node.js + Express.js
- **Database Layer:** Google Sheets API via a Service Account (`googleapis`)
- **Messaging Layer:** Twilio WhatsApp Sandbox
- **AI Speech Pipeline (Sarvam AI):**
  - `saaras:v3` — Speech-to-Text (STT)
  - `sarvam-30b` — Intent Classification & LLM Response Generation
  - `bulbul:v3` — Text-to-Speech (TTS) Voice Reply
- **Media:** FFmpeg for real-time audio conversion to WhatsApp-compatible `.ogg/Opus`
- **Scheduler:** `node-cron` for background follow-up loops
- **Email:** Nodemailer via Gmail SMTP

#### Architecture

```
[WhatsApp Webhook]
       |
       v
[Express Server / Classifier]
  |-- Text Reply? → Approval Handler → Sheets + Email
  └-- Voice Note? → FFmpeg Decode → Sarvam STT → LLM → TTS → FFmpeg Encode → Voice Reply

[Background Cron - every hour]
       |
       v
[Follow-up Engine]
  |-- Pending < threshold? → Send Reminder
  └-- Pending > threshold? → Escalate to Lead via Email
```

---

### PS-4 · YouTube Channel Growth Reporting Agent

**The Big Idea:** A YouTube management agency handles multiple channels. Generating a meaningful monthly performance report for each channel — with video rankings, sentiment analysis, strategic insights, and email delivery — used to take an analyst hours per client. This agent does it autonomously in seconds.

#### How It Works — End to End

```
Provide channel handle(s) → Agent fetches last 30 days of videos
    → Ranks by views & engagement → Extracts top comments
    → Runs deep AI sentiment & thematic analysis (ResearchEngine)
    → Fallback deterministic analysis if AI unavailable
    → Renders premium terminal dashboard
    → Dispatches professional report email to client
```

#### Core Capabilities

| Feature | Description |
|---|---|
| **Multi-channel Batch Processing** | Processes a predefined list of YouTube channels sequentially |
| **Smart Channel Resolution** | Accepts handles (`@name`) or raw channel IDs interchangeably |
| **30-Day Video Analytics** | Fetches and ranks all uploads from the past month with views, likes, engagement rate |
| **Comment Sentiment Mining** | Extracts top comments and performs keyword/theme/sentiment analysis |
| **ResearchEngine Module** | Dedicated AI sub-agent for deep strategic research using LLM analysis |
| **Dual-Mode AI** | Sarvam AI LLM for insight polishing; falls back to deterministic engine if API is unavailable |
| **Rich Terminal Dashboard** | Premium CLI UI using the `rich` library with tables, panels, and dual-column layouts |
| **Automated Email Reports** | Auto-sends formatted monthly reports to each channel's designated email recipient |

#### Technology Stack

- **Runtime:** Python 3.x
- **YouTube Data:** YouTube Data API v3 (channels, videos, comments)
- **AI Layer (Sarvam AI):** `sarvam-2b` LLM via OpenAI-compatible client
- **Research Module:** Custom `ResearchEngine` class with AI-orchestrated strategic analysis
- **Deterministic Fallback:** Keyword frequency analysis without external AI dependency
- **Terminal UI:** `rich` library (Console, Table, Panel, Columns, Progress)
- **Email Dispatch:** `smtplib` + `email.mime` via Gmail SMTP

#### Agent Pipeline

```
YouTubeReportingAgent
  |
  |-- Phase 1: resolve_channel_id()              → Accepts handle or raw ID
  |-- Phase 2: get_uploads_playlist()            → Fetch channel uploads playlist
  |-- Phase 3: fetch_last_month_videos()         → Filter to 30-day window
  |-- Phase 4: fetch_video_metrics()             → Views, likes, engagement rank
  |-- Phase 5: fetch_top_comments()              → Top 15 comments per video
  |-- Phase 6: run_fallback_analysis()           → Deterministic NLP (keyword/sentiment)
  |-- Phase 7: ResearchEngine.deep_research()    → AI strategic briefing
  |-- Phase 8: display_terminal_dashboard()      → Rich CLI output
  └-- Phase 9: dispatch_email_report()           → Gmail email to client
```

---

## Cross-Project Patterns

Both modules share a common architecture philosophy:

| Pattern | PS-3 (WhatsApp) | PS-4 (YouTube) |
|---|---|---|
| **AI Provider** | Sarvam AI (Hindi-first speech) | Sarvam AI (LLM analysis) |
| **Fallback Safety** | Sheets-powered response if AI fails | Deterministic engine if LLM fails |
| **Email Automation** | Nodemailer (Node.js) | smtplib (Python) |
| **Data Source** | Google Sheets (real-time) | YouTube Data API v3 |
| **Scheduling** | node-cron background loop | Sequential batch client loop |

---

## Security

All API keys, tokens, and credentials are managed via `.env` files and are never committed to version control via `.gitignore`.

```env
# PS-3
SPREADSHEET_ID=
TWILIO_ACCOUNT_SID=
TWILIO_AUTH_TOKEN=
SARVAM_API_KEY=
EMAIL_USER=
EMAIL_PASS=
BASE_URL=

# PS-4
YOUTUBE_API_KEY=
SARVAM_API_KEY=
EMAIL_SENDER=
EMAIL_APP_PASSWORD=
EMAIL_RECEIVER=
```

---

## Getting Started

### PS-3: WhatsApp Server

```bash
cd "PS 3/whatsapp_server"
npm install
node index.js
# In a separate terminal:
ngrok http 3000
# Paste ngrok URL into Twilio Sandbox Webhook → /whatsapp
```

### PS-4: YouTube Agent

```bash
cd PS-4/Backup7/Part1
pip install openai requests python-dotenv rich
python youtube_agent.py
```

---

## Author

**Srita** · [@sritahehehe](https://github.com/sritahehehe)

*SILICON — Automated Intelligence, Engineered for Production.*
